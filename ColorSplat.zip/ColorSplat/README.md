# ColorSplat

Vi som har gjort spelet heter: Elin Alm, Christian Ågren, Alexander Bryngelsson, Filip Sunnemar, Matin Atai Najafi

Länk till GitHub-demo: https://elinalm.github.io/ColorSplat/

Länk till Github-konton: https://github.com/elinalm
https://github.com/ChristianAgren
https://github.com/alexbryw
https://github.com/MattinNajafi
https://github.com/Condif

Detta är Colorsplat. Det är ett multiplayerspel som går ut på att färga en så stor yta som möjligt av spelbrädet med sin kanon. Det går att antingen välja att spela 1, 2 eller 3 spelare. Tiden som erbjuds att spela är 45, 60, 90 eller 120 sek. När antalet spelare är valda och tiden bestämd så kommer man vidare till spelbrädet genom att klicka på "starta". Då byter skärmen utseende och man kommer vidare till spelet. Då har det antalet spelade man valde ritats ut som kanoner med förmågan att skjuta projektiler. Varje spelare använder sig av tre knappar för att styra och skjuta med sin kanon. Varje spelare kan styra sin kanons pipa till höger eller vänster medan kroppen på kanonen är statisk under spelets gång. Genom att hålla in skjutknappen spelaren är tilldelad så laddar man sin projektil, när man släpper sin skjutknapp skjuts projektilen iväg. När man är nöjd vart projektilen befinner sig på spelbrädet och vill detonera den trycker man in sin skjutsknapp igen. Då ritas ens egen kanons färg ut som ett splash på spelbrädet. Spelbrädet rör sig under spelets gång mellan höger och vänster på skärmen. Då och då kommer det powerups ner från skärmens överkant. Det är så spelarnas uppgift att skjuta på dessa powerups för att ta till sig deras kraft. Det finns två typer av powerups. En powerup kommer att göra att nästa projektil en spelare skickar ut kommer att detonera på en större yta på spelbrädet så att spelaren får en större del färglagd i sin färg än vid vanliga skott. Den andra powerupen ger spelaren tre projektiler som går snabbare att ladda om. Vanligtvis så har spelarna en coolDown på sina kanoner efter att en projektil har detonerat, denna tid halveras när spelaren lyckas fånga denna powerup. När timern har kommit till 0 så skrivs det ut en scoreboard som visar procentuellt vem som har vunnit omgången. Denna uträkning görs genom att räkna pixlarna på spelbrädet och se hur många procent av spelbrädet som är färglagt av respektive spelares färg. Det finns sedan en möjlighet att klicka på "click to restart game" och då kommer man vidare till startmenyn där man får göra val angående spelare och tid igen.

